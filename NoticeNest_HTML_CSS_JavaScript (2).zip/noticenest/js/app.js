(() => {
  "use strict";

  const STORAGE_KEY = "noticenest_notices_v1";
  const RESPONSE_KEY = "noticenest_responses_v1";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const now = Date.now();
  const hours = n => now + n * 60 * 60 * 1000;

  const starterNotices = [
    {id:"n01",title:"Municipal Water Pipeline Repairs Tomorrow 9 AM - 2 PM",category:"Alerts",description:"The municipal team will carry out scheduled pipeline repairs near the north entrance. Water supply may be interrupted between 9 AM and 2 PM. Please store enough water in advance.",contactName:"Greenwood Admin",contact:"+91 90000 10001",neighborhood:"Greenwood Heights",createdAt:hours(-1),expiryDate:hours(48),isPinned:true,isEmergency:true,icon:"🚰",latitude:17.448,longitude:78.391},
    {id:"n02",title:"Power maintenance in Block C",category:"Alerts",description:"Planned electrical maintenance is scheduled for Block C. Please switch off sensitive appliances during the maintenance window.",contactName:"Facilities Desk",contact:"+91 90000 10002",neighborhood:"Block C",createdAt:hours(-3),expiryDate:hours(24),isPinned:true,isEmergency:true,icon:"⚡",latitude:17.45,longitude:78.393},
    {id:"n03",title:"Weekend mathematics tutor available",category:"Help Wanted",description:"Looking for a patient tutor for a class 8 student. Weekend afternoon sessions preferred. Please share your experience and availability.",contactName:"Ananya Rao",contact:"+91 98765 10003",neighborhood:"Greenwood Heights",createdAt:hours(-5),expiryDate:hours(72),icon:"📚"},
    {id:"n04",title:"Need a plumber for kitchen tap repair",category:"Help Wanted",description:"Our kitchen tap has a small leak. Looking for a reliable plumber who can visit this evening. Recommendations are welcome.",contactName:"Rahul M.",contact:"+91 98765 10004",neighborhood:"Tower 2",createdAt:hours(-8),expiryDate:hours(48),icon:"🔧"},
    {id:"n05",title:"Can someone help with balcony plants?",category:"Help Wanted",description:"I will be away for three days and need a neighbor to water a few balcony plants. Happy to return the favor.",contactName:"Meera S.",contact:"+91 98765 10005",neighborhood:"Tower 1",createdAt:hours(-12),expiryDate:hours(72),icon:"🪴"},
    {id:"n06",title:"Looking for a weekend science tutor",category:"Help Wanted",description:"Seeking a science tutor for class 6. One or two sessions per week. Please contact with timings and references.",contactName:"Kiran P.",contact:"+91 98765 10006",neighborhood:"Greenwood Heights",createdAt:hours(-20),expiryDate:hours(168),icon:"🧪"},
    {id:"n07",title:"Solid wood study table — good condition",category:"For Sale",description:"Sturdy study table with two drawers. Lightly used and well maintained. Buyer can inspect before purchase.",contactName:"Sanjay R.",contact:"+91 98765 10007",neighborhood:"Tower 3",createdAt:hours(-2),expiryDate:hours(168),icon:"🪑",price:"₹2,500"},
    {id:"n08",title:"Two-seater sofa available",category:"For Sale",description:"Compact two-seater sofa in charcoal fabric. Clean and comfortable, suitable for a small living room.",contactName:"Divya K.",contact:"+91 98765 10008",neighborhood:"Block A",createdAt:hours(-10),expiryDate:hours(168),icon:"🛋️",price:"₹4,000"},
    {id:"n09",title:"Bookshelf with five shelves",category:"For Sale",description:"Wooden bookshelf in good condition. Selling because of a home rearrangement. Pickup from Tower 1.",contactName:"Arjun N.",contact:"+91 98765 10009",neighborhood:"Tower 1",createdAt:hours(-18),expiryDate:hours(168),icon:"📚",price:"₹1,200"},
    {id:"n10",title:"Dining chairs — set of four",category:"For Sale",description:"Four matching dining chairs, sturdy frames with comfortable seats. Minor signs of use.",contactName:"Pooja V.",contact:"+91 98765 10010",neighborhood:"Block B",createdAt:hours(-25),expiryDate:hours(168),icon:"🪑",price:"₹3,000"},
    {id:"n11",title:"Children's bicycle for sale",category:"For Sale",description:"A well-maintained children's bicycle. Suitable for a beginner. Please message for more details.",contactName:"Naveen T.",contact:"+91 98765 10011",neighborhood:"Greenwood Heights",createdAt:hours(-30),expiryDate:hours(168),icon:"🚲",price:"₹1,800"},
    {id:"n12",title:"Lost ginger cat near the garden",category:"Lost & Found",description:"Our friendly ginger cat Milo was last seen near the central garden. Please contact us if you spot him.",contactName:"Sneha D.",contact:"+91 98765 10012",neighborhood:"Central Garden",createdAt:hours(-4),expiryDate:hours(72),icon:"🐈"},
    {id:"n13",title:"Found a blue school water bottle",category:"Lost & Found",description:"Found near the children's play area this morning. The owner can identify the sticker on the bottle.",contactName:"Security Desk",contact:"+91 90000 10013",neighborhood:"Play Area",createdAt:hours(-7),expiryDate:hours(72),icon:"🧴"},
    {id:"n14",title:"Missing small white dog — please help",category:"Lost & Found",description:"A small white dog went missing around the east parking area. Please check nearby lanes and contact the family with any information.",contactName:"Vikram S.",contact:"+91 98765 10014",neighborhood:"East Parking",createdAt:hours(-9),expiryDate:hours(72),icon:"🐕"},
    {id:"n15",title:"Found house keys near the entrance",category:"Lost & Found",description:"A set of keys was found near the main entrance. Please contact the security desk and describe the keychain to collect.",contactName:"Greenwood Security",contact:"+91 90000 10015",neighborhood:"Main Entrance",createdAt:hours(-14),expiryDate:hours(72),icon:"🔑"}
  ];

  let notices = loadNotices();
  let responses = JSON.parse(localStorage.getItem(RESPONSE_KEY) || "{}");
  let activeCategory = "All";
  let userPosition = null;
  let soundEnabled = false;
  let audioContext = null;
  let selectedNoticeId = null;

  function loadNotices() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(starterNotices));
        return starterNotices;
      }
      return JSON.parse(saved);
    } catch (error) {
      console.warn("Could not read saved notices; loading starter data.", error);
      return starterNotices;
    }
  }
  function saveNotices() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notices));
  }
  function activeNotices() {
    const before = notices.length;
    notices = notices.filter(item => Number(item.expiryDate) > Date.now());
    if (notices.length !== before) saveNotices();
    return notices;
  }
  function escapeHTML(value = "") {
    return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
  }
  function categoryClass(category) {
    return ({"Alerts":"alert","Help Wanted":"help","For Sale":"sale","Lost & Found":"lost","Community Events":"event"})[category] || "help";
  }
  function categoryIcon(category) {
    return ({"Alerts":"🚨","Help Wanted":"🤝","For Sale":"🏷️","Lost & Found":"🔎","Community Events":"🎉"})[category] || "📌";
  }
  function timeAgo(timestamp) {
    const minutes = Math.max(0, Math.floor((Date.now() - Number(timestamp)) / 60000));
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (minutes < 1440) return `${Math.floor(minutes / 60)}h ago`;
    return `${Math.floor(minutes / 1440)}d ago`;
  }
  function timeLeft(expiry) {
    const remaining = Number(expiry) - Date.now();
    if (remaining <= 0) return "Expired";
    const days = Math.floor(remaining / 86400000);
    const hrs = Math.floor((remaining % 86400000) / 3600000);
    const mins = Math.floor((remaining % 3600000) / 60000);
    return days ? `${days}d ${hrs}h left` : hrs ? `${hrs}h ${mins}m left` : `${mins}m left`;
  }
  function toast(message, type = "success") {
    const node = document.createElement("div");
    node.className = `toast ${type}`;
    node.textContent = message;
    $("#toastRegion").append(node);
    setTimeout(() => node.remove(), 3400);
  }
  function sortNotices(items) {
    const mode = $("#sortSelect").value;
    return [...items].sort((a,b) => {
      if (mode === "newest") return Number(b.createdAt) - Number(a.createdAt);
      if (mode === "oldest") return Number(a.createdAt) - Number(b.createdAt);
      const priority = Number(Boolean(b.isEmergency && b.isPinned)) - Number(Boolean(a.isEmergency && a.isPinned));
      return priority || Number(b.createdAt) - Number(a.createdAt);
    });
  }
  function renderPinned() {
    const pinned = activeNotices().filter(item => item.isPinned && item.isEmergency);
    $("#pinnedAlerts").innerHTML = pinned.length ? pinned.map(item => `
      <article class="pinned-alert">
        <div class="alert-symbol">${escapeHTML(item.icon || "⚠️")}</div>
        <div class="pinned-copy"><h3>${escapeHTML(item.title)}</h3><p>${escapeHTML(item.description)}</p></div>
        <div class="alert-meta">${timeLeft(item.expiryDate)}</div>
        <div class="alert-actions"><button class="outline-red" data-open="${escapeHTML(item.id)}">View details ↗</button></div>
      </article>`).join("") : `<div class="pinned-alert"><div class="alert-symbol">✓</div><div class="pinned-copy"><h3>No active emergency announcements</h3><p>There are no pinned emergency notices right now.</p></div></div>`;
    $("#emergencyStat").textContent = activeNotices().filter(n => n.isEmergency).length;
    $("#alertCount").textContent = pinned.length;
  }
  function getFiltered() {
    const query = $("#searchInput").value.trim().toLowerCase();
    const radius = $("#radiusSelect").value;
    return sortNotices(activeNotices().filter(item => {
      const categoryMatch = activeCategory === "All" || item.category === activeCategory;
      const text = `${item.title} ${item.description} ${item.category} ${item.neighborhood} ${item.contactName}`.toLowerCase();
      const searchMatch = !query || text.includes(query);
      let distanceMatch = true;
      if (radius !== "all") {
        if (!userPosition || typeof item.latitude !== "number" || typeof item.longitude !== "number") distanceMatch = false;
        else distanceMatch = distanceBetween(userPosition.lat,userPosition.lon,item.latitude,item.longitude) <= Number(radius);
      }
      return categoryMatch && searchMatch && distanceMatch;
    }));
  }
  function renderCards() {
    const filtered = getFiltered();
    $("#noticeGrid").innerHTML = filtered.map(item => {
      const image = item.imageUrl && /^https?:\/\//i.test(item.imageUrl) ? `<img src="${escapeHTML(item.imageUrl)}" alt="" loading="lazy" onerror="this.remove()">` : "";
      const placeholder = image ? "" : `<div class="image-placeholder">${escapeHTML(item.icon || categoryIcon(item.category))}</div>`;
      return `<article class="notice-card">
        <div class="card-image">${image}${placeholder}<span class="category-badge ${categoryClass(item.category)}">${escapeHTML(item.category)}</span></div>
        <div class="card-body">
          <div class="card-meta"><span>${escapeHTML(item.neighborhood || "Greenwood Heights")}</span><span>${item.isPinned ? '<b class="pin-mini">◆ PINNED</b>' : timeAgo(item.createdAt)}</span></div>
          <h3>${escapeHTML(item.title)}</h3><p>${escapeHTML(item.description)}</p>
          <div class="card-footer"><div class="contact-mini"><span class="person-dot">${escapeHTML((item.contactName || "N").slice(0,1).toUpperCase())}</span><span>${escapeHTML(item.contactName || "Neighbor")}</span></div>
            <div class="card-buttons"><button class="small-action" data-open="${escapeHTML(item.id)}">Details</button>${item.category === "Help Wanted" ? `<button class="small-action" data-help="${escapeHTML(item.id)}">Offer help</button>` : ""}</div></div>
          <div class="expiry">◷ ${timeLeft(item.expiryDate)} ${item.price ? ` · <b>${escapeHTML(item.price)}</b>` : ""}</div>
        </div></article>`;
    }).join("");
    $("#emptyState").classList.toggle("hidden", filtered.length > 0);
    $("#noticeGrid").classList.toggle("hidden", filtered.length === 0);
    $("#resultsText").textContent = `Showing ${filtered.length} of ${activeNotices().length} active notices`;
    $("#activeStat").textContent = activeNotices().length;
    $("#allCount").textContent = activeNotices().length;
    $("#helpStat").textContent = String(activeNotices().filter(n => n.category === "Help Wanted").length + 4).padStart(2,"0");
  }
  function render() { renderPinned(); renderCards(); }
  function distanceBetween(lat1,lon1,lat2,lon2) {
    const rad = value => value * Math.PI / 180;
    const dLat = rad(lat2-lat1), dLon = rad(lon2-lon1);
    const a = Math.sin(dLat/2)**2 + Math.cos(rad(lat1))*Math.cos(rad(lat2))*Math.sin(dLon/2)**2;
    return 6371000 * 2 * Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
  }
  function openModal(id) { $( "#" + id ).classList.remove("hidden"); document.body.style.overflow = "hidden"; }
  function closeModal(id) { $("#" + id).classList.add("hidden"); if (!$(".modal-backdrop:not(.hidden)") && !$(".drawer-backdrop:not(.hidden)")) document.body.style.overflow = ""; }
  function openDetails(id) {
    const item = activeNotices().find(n => n.id === id);
    if (!item) return;
    selectedNoticeId = id;
    const itemResponses = responses[id] || [];
    const image = item.imageUrl && /^https?:\/\//i.test(item.imageUrl) ? `<img class="detail-image" src="${escapeHTML(item.imageUrl)}" alt="Notice image">` : "";
    $("#detailContent").innerHTML = `${image}<span class="category-badge ${categoryClass(item.category)}">${escapeHTML(item.category)}</span><h2 id="detailTitle">${escapeHTML(item.title)}</h2><p class="detail-description">${escapeHTML(item.description)}</p>
      <div class="detail-info"><div><span>Posted by</span><b>${escapeHTML(item.contactName)}</b></div><div><span>Neighborhood</span><b>${escapeHTML(item.neighborhood || "Greenwood Heights")}</b></div><div><span>Contact</span><b>${escapeHTML(item.contact)}</b></div><div><span>Expires</span><b>${timeLeft(item.expiryDate)}</b></div>${item.price ? `<div><span>Price</span><b>${escapeHTML(item.price)}</b></div>` : ""}</div>
      <div class="modal-actions"><button class="secondary-button" id="shareNotice">Share ↗</button><a class="primary-button" style="text-decoration:none" href="tel:${encodeURIComponent(item.contact)}">Contact neighbor</a></div>
      <div class="response-box"><h3>Neighbor responses (${itemResponses.length})</h3><div class="response-list">${itemResponses.length ? itemResponses.map(r=>`<div class="response-item">${escapeHTML(r.message)}<small>${escapeHTML(r.name)} · ${timeAgo(r.createdAt)}</small></div>`).join("") : `<div class="response-item">No responses yet. Be the first to offer a hand.</div>`}</div>
      <form class="response-form" id="responseForm"><textarea name="message" required rows="3" maxlength="300" placeholder="Write a helpful reply or offer..."></textarea><button class="primary-button">Send response</button></form></div>`;
    $("#detailBackdrop").classList.remove("hidden");
    document.body.style.overflow = "hidden";
    $("#shareNotice").addEventListener("click", () => shareNotice(item));
    $("#responseForm").addEventListener("submit", event => {
      event.preventDefault();
      const message = new FormData(event.currentTarget).get("message").trim();
      if (!message) return;
      responses[id] = responses[id] || [];
      responses[id].push({name:"Bhanu Prakash",message,createdAt:Date.now()});
      localStorage.setItem(RESPONSE_KEY,JSON.stringify(responses));
      toast("Your response was added.");
      openDetails(id);
    });
  }
  function closeDrawer() { $("#detailBackdrop").classList.add("hidden"); document.body.style.overflow = ""; }
  function shareNotice(item) {
    const message = `${item.title}\n${item.category} · ${item.neighborhood || "Greenwood Heights"}\n${item.description}\nExpires: ${new Date(Number(item.expiryDate)).toLocaleString()}\nShared via NoticeNest`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`,"_blank","noopener,noreferrer");
  }
  function publishNotice(formData) {
    const title = String(formData.get("title") || "").trim();
    const description = String(formData.get("description") || "").trim();
    const contact = String(formData.get("contact") || "").trim();
    const imageUrl = String(formData.get("imageUrl") || "").trim();
    if (!title || !description || !contact) throw new Error("Please complete all required fields.");
    if (imageUrl && !/^https?:\/\//i.test(imageUrl)) throw new Error("Image URL must start with http:// or https://.");
    const expiryDate = Date.now() + Number(formData.get("expiry")) * 3600000;
    const notice = {id:`user-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,title,category:String(formData.get("category")),description,contactName:String(formData.get("contactName")).trim(),contact,imageUrl,neighborhood:String(formData.get("neighborhood") || "Greenwood Heights").trim(),createdAt:Date.now(),expiryDate,isPinned:false,isEmergency:false,icon:categoryIcon(String(formData.get("category")))};
    notices.unshift(notice);
    saveNotices();
    render();
    closeModal("postModal");
    $("#noticeForm").reset();
    toast("Your notice is now live in the community.", "success");
  }
  function setCategory(category) {
    activeCategory = category;
    $$(".category-tab").forEach(button => button.classList.toggle("active",button.dataset.category === category));
    renderCards();
  }
  function requestLocation() {
    if (!navigator.geolocation) { toast("Geolocation is not supported by this browser.","error"); return; }
    $("#locationButton").textContent = "⌖ Locating...";
    navigator.geolocation.getCurrentPosition(position => {
      userPosition = {lat:position.coords.latitude,lon:position.coords.longitude};
      $("#locationButton").textContent = "✓ Location ready";
      if ($("#radiusSelect").value === "all") $("#radiusSelect").value = "5000";
      renderCards();
      toast("Your nearby notices are ready.");
    }, () => {
      $("#locationButton").textContent = "⌖ Use my location";
      toast("Location permission was unavailable. You can still browse all notices.","error");
    },{enableHighAccuracy:false,timeout:10000,maximumAge:300000});
  }
  function playAlertTone() {
    if (!soundEnabled) return;
    try {
      audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
      if (audioContext.state === "suspended") audioContext.resume();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = "sine"; oscillator.frequency.value = 740;
      gain.gain.setValueAtTime(0.0001,audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.08,audioContext.currentTime + .04);
      gain.gain.exponentialRampToValueAtTime(0.0001,audioContext.currentTime + .48);
      oscillator.connect(gain); gain.connect(audioContext.destination);
      oscillator.start(); oscillator.stop(audioContext.currentTime + .5);
    } catch (error) { console.warn("Audio alert unavailable.",error); }
  }

  $("#openPost").addEventListener("click",()=>openModal("postModal"));
  $("#noticeForm").addEventListener("submit",event=>{event.preventDefault();try{publishNotice(new FormData(event.currentTarget));}catch(error){toast(error.message,"error");}});
  $$(".category-tab").forEach(button=>button.addEventListener("click",()=>setCategory(button.dataset.category)));
  $("#searchInput").addEventListener("input",renderCards);
  $("#sortSelect").addEventListener("change",renderCards);
  $("#radiusSelect").addEventListener("change",()=>{if($("#radiusSelect").value!=="all"&&!userPosition)requestLocation();else renderCards();});
  $("#locationButton").addEventListener("click",requestLocation);
  $("#clearFilters").addEventListener("click",clearFilters);
  $("#emptyClear").addEventListener("click",clearFilters);
  function clearFilters(){ $("#searchInput").value="";$("#radiusSelect").value="all";setCategory("All");renderCards(); }
  $("#noticeGrid").addEventListener("click",event=>{
    const open = event.target.closest("[data-open]");
    const help = event.target.closest("[data-help]");
    if(open) openDetails(open.dataset.open);
    else if(help) openDetails(help.dataset.help);
  });
  $("#pinnedAlerts").addEventListener("click",event=>{const button=event.target.closest("[data-open]");if(button)openDetails(button.dataset.open);});
  $("#closeDrawer").addEventListener("click",closeDrawer);
  $("#detailBackdrop").addEventListener("click",event=>{if(event.target===$("#detailBackdrop"))closeDrawer();});
  $$("[data-close]").forEach(button=>button.addEventListener("click",()=>closeModal(button.dataset.close)));
  $$(".modal-backdrop").forEach(backdrop=>backdrop.addEventListener("click",event=>{if(event.target===backdrop)closeModal(backdrop.id);}));
  $("#verifyOpen").addEventListener("click",()=>openModal("verifyModal"));
  $("#verifyForm").addEventListener("submit",event=>{event.preventDefault();closeModal("verifyModal");toast("Verification request submitted (demo mode).");});
  $("#soundToggle").addEventListener("click",()=>{
    soundEnabled=!soundEnabled;
    $("#soundToggle").classList.toggle("sound-on",soundEnabled);
    toast(soundEnabled?"Emergency sound enabled.":"Emergency sound muted.");
    if(soundEnabled)playAlertTone();
  });
  $("#notificationButton").addEventListener("click",()=>toast(`${activeNotices().filter(n=>n.isEmergency).length} active emergency notices in your community.`));
  $("#menuToggle").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
  $$(".nav-link").forEach(link=>link.addEventListener("click",()=>$("#sidebar").classList.remove("open")));
  document.addEventListener("keydown",event=>{
    if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="k"){event.preventDefault();$("#searchInput").focus();}
    if(event.key==="Escape"){closeDrawer();["postModal","verifyModal"].forEach(closeModal);}
  });

  // Expiry is checked at startup and on each periodic refresh; expired items are removed from the active local feed.
  render();
  setInterval(render,60000);
  window.addEventListener("storage",event=>{if(event.key===STORAGE_KEY){notices=loadNotices();render();}});
})();