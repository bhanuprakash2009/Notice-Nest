# NoticeNest — NeighbourNet

A responsive community notice board demo built with semantic HTML, CSS and Vanilla JavaScript.

## Run
1. Extract the project.
2. Open `index.html` in a modern browser.

For best results, serve the folder with a local static server (for example, VS Code Live Server). Geolocation requires localhost or HTTPS.

## Included
- Five notice categories, search and category filters
- Emergency pinned banner
- Notice creation with 24-hour, 3-day and 7-day expiry
- LocalStorage persistence and expiry cleanup
- Notice detail drawer and neighbor responses
- WhatsApp sharing
- Geolocation radius filter (500m, 1km, 5km)
- Simulated resident verification request
- Opt-in Web Audio emergency tone
- Responsive desktop, tablet and mobile layouts

## Demo limitations
This is a frontend-only implementation. The starter dataset and user-created notices are stored in browser LocalStorage. Resident verification is simulated, not an identity check. Emergency pinning is preconfigured for the two sample alerts; secure admin authorization and a shared SQLite/Express backend require a server-side implementation before production use.
